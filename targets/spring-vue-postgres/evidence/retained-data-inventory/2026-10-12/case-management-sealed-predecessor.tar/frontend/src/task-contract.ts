import { call } from './api';
export type QueryInput = { "QUERY-TEXT": string };
export type TaskInput = { "INPUT-TASK-RESOURCE": string; "INPUT-TASK-TEXT": string };
export type TaskOutput = { "OUTPUT-TASK-TEXT": string };
export type TaskCompletion = { output: TaskOutput; resourceId: string; version: number; state: string | null };
export type ActionRequest = { expectedVersion: number; idempotencyKey: string; input: TaskInput };
export const resourceInputField = "INPUT-TASK-RESOURCE";
export function queryInput(text: string): QueryInput { return { "QUERY-TEXT": text }; }
export function taskInput(values: Partial<TaskInput>, resourceId: string): TaskInput {
 const text=values["INPUT-TASK-TEXT"]; if(text===undefined || text==='') throw new Error('INVALID_TASK_INPUT');
 return { "INPUT-TASK-RESOURCE": resourceId, "INPUT-TASK-TEXT": text };
}
export function queryTasks(text: string): Promise<TaskCompletion[]> {
 return call<TaskCompletion[]>("/api/op_647d32adf46be996dd32e08b?offset=0&limit=50",queryInput(text));
}
export function submitTask(values: Partial<TaskInput>,resourceId: string,expectedVersion: number,idempotencyKey: string): Promise<TaskCompletion> {
 const body:ActionRequest={expectedVersion,idempotencyKey,input:taskInput(values,resourceId)};
 return call<TaskCompletion>("/api/op_225e20f12f0b359413f7a725",body);
}
