export { ui as model } from './task-ui-model';
