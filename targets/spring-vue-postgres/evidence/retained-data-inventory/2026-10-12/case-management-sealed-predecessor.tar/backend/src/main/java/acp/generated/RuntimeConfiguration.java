package acp.generated;
@org.springframework.context.annotation.Configuration
public class RuntimeConfiguration {
 @org.springframework.context.annotation.Bean(destroyMethod="close")
 acp.infrastructure.RuntimeBootstrap runtimeBootstrap(org.springframework.jdbc.core.JdbcTemplate jdbc,org.springframework.transaction.PlatformTransactionManager manager,acp.infrastructure.TargetModel model,Invocations invocations,org.springframework.core.env.Environment env,org.springframework.beans.factory.ObjectProvider<acp.infrastructure.JobRuntime.PrincipalPort> principal,org.springframework.beans.factory.ObjectProvider<acp.infrastructure.DeliveryRuntime.Transport> transport) {return new acp.infrastructure.RuntimeBootstrap(jdbc,manager,model,invocations,env,principal,transport);}
 @org.springframework.context.annotation.Bean
 org.springframework.boot.ApplicationRunner startRuntime(acp.infrastructure.RuntimeBootstrap runtime,org.springframework.core.env.Environment env){return args->{if(env.getProperty("acp.runtime.poll-enabled",Boolean.class,true))runtime.start();};}
}
