package acp.generated;
import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.core.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.annotation.*;

/** Generated from exact semantic origins. No map-shaped operation contracts. */
public final class Contracts {
    private Contracts() {}
    public record Slot<T>(boolean present, T value) {
        public Slot { if (!present && value != null) throw new IllegalArgumentException("ABSENT_VALUE"); }
        public static <T> Slot<T> absent() { return new Slot<>(false, null); }
        public static <T> Slot<T> of(T value) { return new Slot<>(true, value); }
    }
    static void shape(JsonNode n, java.util.Set<String> allowed) {
        if (n == null || !n.isObject()) throw new IllegalArgumentException("OBJECT_REQUIRED");
        n.fieldNames().forEachRemaining(k -> { if (!allowed.contains(k)) throw new IllegalArgumentException("UNKNOWN_MEMBER"); });
    }
    static JsonNode required(JsonNode n, String key) { if (!n.has(key)) throw new IllegalArgumentException("REQUIRED_INPUT:" + key); return n.get(key); }
    static boolean blankIdentity(String s) { return s.codePoints().allMatch(cp -> Character.isWhitespace(cp) || Character.isSpaceChar(cp) || cp == 0x85); }
    static void validText(String s) {
        java.util.Objects.requireNonNull(s);
        for (int i=0;i<s.length();i++) {
            char c=s.charAt(i);
            if (Character.isHighSurrogate(c)) { if (++i>=s.length() || !Character.isLowSurrogate(s.charAt(i))) throw new IllegalArgumentException("UNICODE_SCALAR"); }
            else if (Character.isLowSurrogate(c)) throw new IllegalArgumentException("UNICODE_SCALAR");
        }
    }
    static String text(JsonNode n) { if (n == null || !n.isTextual()) throw new IllegalArgumentException("STRING_REQUIRED"); String s=n.textValue(); validText(s); return s; }
    static Boolean bool(JsonNode n) { if (n == null || !n.isBoolean()) throw new IllegalArgumentException("BOOLEAN_REQUIRED"); return n.booleanValue(); }
    static java.math.BigDecimal decimal(JsonNode n) {
        String s=text(n);
        if (s.length()>128 || !s.matches("-?(0|[1-9][0-9]*)(\\.[0-9]+)?")) throw new IllegalArgumentException("DECIMAL_REPRESENTATION");
        return new java.math.BigDecimal(s);
    }
    static Long integer(JsonNode n) { if (n == null || !n.isIntegralNumber() || !n.canConvertToLong()) throw new IllegalArgumentException("INTEGER_REQUIRED"); return n.longValue(); }

    @JsonDeserialize(using=T_30b82cbe46f23754678604ec.Reader.class)
    @JsonSerialize(using=T_30b82cbe46f23754678604ec.Writer.class)
    public record T_30b82cbe46f23754678604ec(@JsonProperty("APPROVAL-ID") T_30b82cbe46f23754678604ecId v_a39e330cc367ff236918ed56, @JsonProperty("APPROVAL-TENANT") T_0e6739cd5c48f9356c70c968Id v_545cf7ffac08d365f11a73f2, @JsonProperty("APPROVAL-reason") String v_7e91cd8a50f971e354e5130a) {
        public T_30b82cbe46f23754678604ec {    java.util.Objects.requireNonNull(v_a39e330cc367ff236918ed56, "APPROVAL-ID"); java.util.Objects.requireNonNull(v_545cf7ffac08d365f11a73f2, "APPROVAL-TENANT"); java.util.Objects.requireNonNull(v_7e91cd8a50f971e354e5130a, "APPROVAL-reason"); if (v_7e91cd8a50f971e354e5130a != null) validText(v_7e91cd8a50f971e354e5130a); }
        public static T_30b82cbe46f23754678604ec read(JsonNode n) {
            shape(n, java.util.Set.of("APPROVAL-ID", "APPROVAL-TENANT", "APPROVAL-reason"));
            return new T_30b82cbe46f23754678604ec(new T_30b82cbe46f23754678604ecId(text(required(n, "APPROVAL-ID"))), new T_0e6739cd5c48f9356c70c968Id(text(required(n, "APPROVAL-TENANT"))), text(required(n, "APPROVAL-reason")));
        }
        public static final class Reader extends JsonDeserializer<T_30b82cbe46f23754678604ec> {
            @Override public T_30b82cbe46f23754678604ec deserialize(JsonParser p, DeserializationContext c) throws java.io.IOException {
                try { return read(p.getCodec().readTree(p)); }
                catch (RuntimeException e) { throw JsonMappingException.from(p, "SEMANTIC_INPUT", e); }
            }
        }
        public static final class Writer extends JsonSerializer<T_30b82cbe46f23754678604ec> {
            @Override public void serialize(T_30b82cbe46f23754678604ec value, JsonGenerator g, SerializerProvider p) throws java.io.IOException {
                value.write(g);
            }
        }
        private void write(JsonGenerator g) throws java.io.IOException {
            g.writeStartObject(); g.writeObjectField("APPROVAL-ID", v_a39e330cc367ff236918ed56); g.writeObjectField("APPROVAL-TENANT", v_545cf7ffac08d365f11a73f2); g.writeObjectField("APPROVAL-reason", v_7e91cd8a50f971e354e5130a); g.writeEndObject();
        }
    }

public record T_30b82cbe46f23754678604ecId(@JsonValue String value) { @JsonCreator(mode=JsonCreator.Mode.DELEGATING) public T_30b82cbe46f23754678604ecId { validText(value); if (blankIdentity(value)) throw new IllegalArgumentException("EMPTY_IDENTITY"); } }

    @JsonDeserialize(using=T_ab04ccc137d58ef30f41dbd2.Reader.class)
    @JsonSerialize(using=T_ab04ccc137d58ef30f41dbd2.Writer.class)
    public record T_ab04ccc137d58ef30f41dbd2(@JsonProperty("ASSIGNMENT-ID") T_ab04ccc137d58ef30f41dbd2Id v_43c60a009b91e45431f6579a, @JsonProperty("ASSIGNMENT-TENANT") T_0e6739cd5c48f9356c70c968Id v_3d0113ab66ba877fa64e2c53, @JsonProperty("ASSIGNMENT-task") String v_dcaf7da954b1d9130557edff) {
        public T_ab04ccc137d58ef30f41dbd2 {    java.util.Objects.requireNonNull(v_43c60a009b91e45431f6579a, "ASSIGNMENT-ID"); java.util.Objects.requireNonNull(v_3d0113ab66ba877fa64e2c53, "ASSIGNMENT-TENANT"); java.util.Objects.requireNonNull(v_dcaf7da954b1d9130557edff, "ASSIGNMENT-task"); if (v_dcaf7da954b1d9130557edff != null) validText(v_dcaf7da954b1d9130557edff); }
        public static T_ab04ccc137d58ef30f41dbd2 read(JsonNode n) {
            shape(n, java.util.Set.of("ASSIGNMENT-ID", "ASSIGNMENT-TENANT", "ASSIGNMENT-task"));
            return new T_ab04ccc137d58ef30f41dbd2(new T_ab04ccc137d58ef30f41dbd2Id(text(required(n, "ASSIGNMENT-ID"))), new T_0e6739cd5c48f9356c70c968Id(text(required(n, "ASSIGNMENT-TENANT"))), text(required(n, "ASSIGNMENT-task")));
        }
        public static final class Reader extends JsonDeserializer<T_ab04ccc137d58ef30f41dbd2> {
            @Override public T_ab04ccc137d58ef30f41dbd2 deserialize(JsonParser p, DeserializationContext c) throws java.io.IOException {
                try { return read(p.getCodec().readTree(p)); }
                catch (RuntimeException e) { throw JsonMappingException.from(p, "SEMANTIC_INPUT", e); }
            }
        }
        public static final class Writer extends JsonSerializer<T_ab04ccc137d58ef30f41dbd2> {
            @Override public void serialize(T_ab04ccc137d58ef30f41dbd2 value, JsonGenerator g, SerializerProvider p) throws java.io.IOException {
                value.write(g);
            }
        }
        private void write(JsonGenerator g) throws java.io.IOException {
            g.writeStartObject(); g.writeObjectField("ASSIGNMENT-ID", v_43c60a009b91e45431f6579a); g.writeObjectField("ASSIGNMENT-TENANT", v_3d0113ab66ba877fa64e2c53); g.writeObjectField("ASSIGNMENT-task", v_dcaf7da954b1d9130557edff); g.writeEndObject();
        }
    }

public record T_ab04ccc137d58ef30f41dbd2Id(@JsonValue String value) { @JsonCreator(mode=JsonCreator.Mode.DELEGATING) public T_ab04ccc137d58ef30f41dbd2Id { validText(value); if (blankIdentity(value)) throw new IllegalArgumentException("EMPTY_IDENTITY"); } }

    @JsonDeserialize(using=T_d35114736c127b0a4f015cde.Reader.class)
    @JsonSerialize(using=T_d35114736c127b0a4f015cde.Writer.class)
    public record T_d35114736c127b0a4f015cde(@JsonProperty("CASE-ASSIGNEE") T_92b7b421992ef490f3b75898Id v_be31db7214bd8af99867f486, @JsonProperty("CASE-ID") T_d35114736c127b0a4f015cdeId v_bf60325b4cdc299c2172f24c, @JsonProperty("CASE-TENANT") T_0e6739cd5c48f9356c70c968Id v_883bd4a687ba22abd76d5b51, @JsonProperty("FLD-CASE-TITLE") T_691c513c3054cfe3d0dd758d v_44b27cbadb64ee9d56f21805, @JsonProperty("FLD-NOTE") Slot<String> v_00dc7107adbf703eb0967a39, @JsonProperty("FLD-TASK-SUMMARY") String v_a3c92c5b2195fe53206f71ca) {
        public T_d35114736c127b0a4f015cde {      java.util.Objects.requireNonNull(v_be31db7214bd8af99867f486, "CASE-ASSIGNEE"); java.util.Objects.requireNonNull(v_bf60325b4cdc299c2172f24c, "CASE-ID"); java.util.Objects.requireNonNull(v_883bd4a687ba22abd76d5b51, "CASE-TENANT"); java.util.Objects.requireNonNull(v_44b27cbadb64ee9d56f21805, "FLD-CASE-TITLE"); java.util.Objects.requireNonNull(v_00dc7107adbf703eb0967a39, "FLD-NOTE"); if (v_00dc7107adbf703eb0967a39.value() != null) validText(v_00dc7107adbf703eb0967a39.value()); java.util.Objects.requireNonNull(v_a3c92c5b2195fe53206f71ca, "FLD-TASK-SUMMARY"); if (v_a3c92c5b2195fe53206f71ca != null) validText(v_a3c92c5b2195fe53206f71ca); }
        public static T_d35114736c127b0a4f015cde read(JsonNode n) {
            shape(n, java.util.Set.of("CASE-ASSIGNEE", "CASE-ID", "CASE-TENANT", "FLD-CASE-TITLE", "FLD-NOTE", "FLD-TASK-SUMMARY"));
            return new T_d35114736c127b0a4f015cde(new T_92b7b421992ef490f3b75898Id(text(required(n, "CASE-ASSIGNEE"))), new T_d35114736c127b0a4f015cdeId(text(required(n, "CASE-ID"))), new T_0e6739cd5c48f9356c70c968Id(text(required(n, "CASE-TENANT"))), T_691c513c3054cfe3d0dd758d.read(required(n, "FLD-CASE-TITLE")), (n.has("FLD-NOTE") ? Slot.of((n.get("FLD-NOTE").isNull() ? null : text(n.get("FLD-NOTE")))) : Slot.absent()), text(required(n, "FLD-TASK-SUMMARY")));
        }
        public static final class Reader extends JsonDeserializer<T_d35114736c127b0a4f015cde> {
            @Override public T_d35114736c127b0a4f015cde deserialize(JsonParser p, DeserializationContext c) throws java.io.IOException {
                try { return read(p.getCodec().readTree(p)); }
                catch (RuntimeException e) { throw JsonMappingException.from(p, "SEMANTIC_INPUT", e); }
            }
        }
        public static final class Writer extends JsonSerializer<T_d35114736c127b0a4f015cde> {
            @Override public void serialize(T_d35114736c127b0a4f015cde value, JsonGenerator g, SerializerProvider p) throws java.io.IOException {
                value.write(g);
            }
        }
        private void write(JsonGenerator g) throws java.io.IOException {
            g.writeStartObject(); g.writeObjectField("CASE-ASSIGNEE", v_be31db7214bd8af99867f486); g.writeObjectField("CASE-ID", v_bf60325b4cdc299c2172f24c); g.writeObjectField("CASE-TENANT", v_883bd4a687ba22abd76d5b51); g.writeObjectField("FLD-CASE-TITLE", v_44b27cbadb64ee9d56f21805); if (v_00dc7107adbf703eb0967a39.present()) g.writeObjectField("FLD-NOTE", v_00dc7107adbf703eb0967a39.value()); g.writeObjectField("FLD-TASK-SUMMARY", v_a3c92c5b2195fe53206f71ca); g.writeEndObject();
        }
    }

public record T_d35114736c127b0a4f015cdeId(@JsonValue String value) { @JsonCreator(mode=JsonCreator.Mode.DELEGATING) public T_d35114736c127b0a4f015cdeId { validText(value); if (blankIdentity(value)) throw new IllegalArgumentException("EMPTY_IDENTITY"); } }

    @JsonDeserialize(using=T_71772a68c6d1eeb195691104.Reader.class)
    @JsonSerialize(using=T_71772a68c6d1eeb195691104.Writer.class)
    public record T_71772a68c6d1eeb195691104(@JsonProperty("COMMENT-ID") T_71772a68c6d1eeb195691104Id v_32eb6cc37d13388ad6567d7c, @JsonProperty("COMMENT-TENANT") T_0e6739cd5c48f9356c70c968Id v_c81a30b823847e1dedb14ae9, @JsonProperty("COMMENT-body") String v_cc44c6f67e1e80ac9b36b6f3) {
        public T_71772a68c6d1eeb195691104 {    java.util.Objects.requireNonNull(v_32eb6cc37d13388ad6567d7c, "COMMENT-ID"); java.util.Objects.requireNonNull(v_c81a30b823847e1dedb14ae9, "COMMENT-TENANT"); java.util.Objects.requireNonNull(v_cc44c6f67e1e80ac9b36b6f3, "COMMENT-body"); if (v_cc44c6f67e1e80ac9b36b6f3 != null) validText(v_cc44c6f67e1e80ac9b36b6f3); }
        public static T_71772a68c6d1eeb195691104 read(JsonNode n) {
            shape(n, java.util.Set.of("COMMENT-ID", "COMMENT-TENANT", "COMMENT-body"));
            return new T_71772a68c6d1eeb195691104(new T_71772a68c6d1eeb195691104Id(text(required(n, "COMMENT-ID"))), new T_0e6739cd5c48f9356c70c968Id(text(required(n, "COMMENT-TENANT"))), text(required(n, "COMMENT-body")));
        }
        public static final class Reader extends JsonDeserializer<T_71772a68c6d1eeb195691104> {
            @Override public T_71772a68c6d1eeb195691104 deserialize(JsonParser p, DeserializationContext c) throws java.io.IOException {
                try { return read(p.getCodec().readTree(p)); }
                catch (RuntimeException e) { throw JsonMappingException.from(p, "SEMANTIC_INPUT", e); }
            }
        }
        public static final class Writer extends JsonSerializer<T_71772a68c6d1eeb195691104> {
            @Override public void serialize(T_71772a68c6d1eeb195691104 value, JsonGenerator g, SerializerProvider p) throws java.io.IOException {
                value.write(g);
            }
        }
        private void write(JsonGenerator g) throws java.io.IOException {
            g.writeStartObject(); g.writeObjectField("COMMENT-ID", v_32eb6cc37d13388ad6567d7c); g.writeObjectField("COMMENT-TENANT", v_c81a30b823847e1dedb14ae9); g.writeObjectField("COMMENT-body", v_cc44c6f67e1e80ac9b36b6f3); g.writeEndObject();
        }
    }

public record T_71772a68c6d1eeb195691104Id(@JsonValue String value) { @JsonCreator(mode=JsonCreator.Mode.DELEGATING) public T_71772a68c6d1eeb195691104Id { validText(value); if (blankIdentity(value)) throw new IllegalArgumentException("EMPTY_IDENTITY"); } }

    @JsonDeserialize(using=T_e52e1d57122da276f479fa74.Reader.class)
    @JsonSerialize(using=T_e52e1d57122da276f479fa74.Writer.class)
    public record T_e52e1d57122da276f479fa74(@JsonProperty("DOCUMENT-ID") T_e52e1d57122da276f479fa74Id v_194194c443fb821c9313280f, @JsonProperty("DOCUMENT-TENANT") T_0e6739cd5c48f9356c70c968Id v_8d7f1351fd0cba964597af46, @JsonProperty("DOCUMENT-title") String v_fbbc390076116aa039060bb9) {
        public T_e52e1d57122da276f479fa74 {    java.util.Objects.requireNonNull(v_194194c443fb821c9313280f, "DOCUMENT-ID"); java.util.Objects.requireNonNull(v_8d7f1351fd0cba964597af46, "DOCUMENT-TENANT"); java.util.Objects.requireNonNull(v_fbbc390076116aa039060bb9, "DOCUMENT-title"); if (v_fbbc390076116aa039060bb9 != null) validText(v_fbbc390076116aa039060bb9); }
        public static T_e52e1d57122da276f479fa74 read(JsonNode n) {
            shape(n, java.util.Set.of("DOCUMENT-ID", "DOCUMENT-TENANT", "DOCUMENT-title"));
            return new T_e52e1d57122da276f479fa74(new T_e52e1d57122da276f479fa74Id(text(required(n, "DOCUMENT-ID"))), new T_0e6739cd5c48f9356c70c968Id(text(required(n, "DOCUMENT-TENANT"))), text(required(n, "DOCUMENT-title")));
        }
        public static final class Reader extends JsonDeserializer<T_e52e1d57122da276f479fa74> {
            @Override public T_e52e1d57122da276f479fa74 deserialize(JsonParser p, DeserializationContext c) throws java.io.IOException {
                try { return read(p.getCodec().readTree(p)); }
                catch (RuntimeException e) { throw JsonMappingException.from(p, "SEMANTIC_INPUT", e); }
            }
        }
        public static final class Writer extends JsonSerializer<T_e52e1d57122da276f479fa74> {
            @Override public void serialize(T_e52e1d57122da276f479fa74 value, JsonGenerator g, SerializerProvider p) throws java.io.IOException {
                value.write(g);
            }
        }
        private void write(JsonGenerator g) throws java.io.IOException {
            g.writeStartObject(); g.writeObjectField("DOCUMENT-ID", v_194194c443fb821c9313280f); g.writeObjectField("DOCUMENT-TENANT", v_8d7f1351fd0cba964597af46); g.writeObjectField("DOCUMENT-title", v_fbbc390076116aa039060bb9); g.writeEndObject();
        }
    }

public record T_e52e1d57122da276f479fa74Id(@JsonValue String value) { @JsonCreator(mode=JsonCreator.Mode.DELEGATING) public T_e52e1d57122da276f479fa74Id { validText(value); if (blankIdentity(value)) throw new IllegalArgumentException("EMPTY_IDENTITY"); } }

    @JsonDeserialize(using=T_199f0e8bb1ffa0c1e9291285.Reader.class)
    @JsonSerialize(using=T_199f0e8bb1ffa0c1e9291285.Writer.class)
    public record T_199f0e8bb1ffa0c1e9291285(@JsonProperty("FLD-CASE-TITLE") T_691c513c3054cfe3d0dd758d v_44b27cbadb64ee9d56f21805) {
        public T_199f0e8bb1ffa0c1e9291285 {  java.util.Objects.requireNonNull(v_44b27cbadb64ee9d56f21805, "FLD-CASE-TITLE"); }
        public static T_199f0e8bb1ffa0c1e9291285 read(JsonNode n) {
            shape(n, java.util.Set.of("FLD-CASE-TITLE"));
            return new T_199f0e8bb1ffa0c1e9291285(T_691c513c3054cfe3d0dd758d.read(required(n, "FLD-CASE-TITLE")));
        }
        public static final class Reader extends JsonDeserializer<T_199f0e8bb1ffa0c1e9291285> {
            @Override public T_199f0e8bb1ffa0c1e9291285 deserialize(JsonParser p, DeserializationContext c) throws java.io.IOException {
                try { return read(p.getCodec().readTree(p)); }
                catch (RuntimeException e) { throw JsonMappingException.from(p, "SEMANTIC_INPUT", e); }
            }
        }
        public static final class Writer extends JsonSerializer<T_199f0e8bb1ffa0c1e9291285> {
            @Override public void serialize(T_199f0e8bb1ffa0c1e9291285 value, JsonGenerator g, SerializerProvider p) throws java.io.IOException {
                value.write(g);
            }
        }
        private void write(JsonGenerator g) throws java.io.IOException {
            g.writeStartObject(); g.writeObjectField("FLD-CASE-TITLE", v_44b27cbadb64ee9d56f21805); g.writeEndObject();
        }
    }


    @JsonDeserialize(using=T_fcbaca28c9b37719d07c2ac4.Reader.class)
    @JsonSerialize(using=T_fcbaca28c9b37719d07c2ac4.Writer.class)
    public record T_fcbaca28c9b37719d07c2ac4(@JsonProperty("FLD-CASE-TITLE") T_691c513c3054cfe3d0dd758d v_44b27cbadb64ee9d56f21805) {
        public T_fcbaca28c9b37719d07c2ac4 {  java.util.Objects.requireNonNull(v_44b27cbadb64ee9d56f21805, "FLD-CASE-TITLE"); }
        public static T_fcbaca28c9b37719d07c2ac4 read(JsonNode n) {
            shape(n, java.util.Set.of("FLD-CASE-TITLE"));
            return new T_fcbaca28c9b37719d07c2ac4(T_691c513c3054cfe3d0dd758d.read(required(n, "FLD-CASE-TITLE")));
        }
        public static final class Reader extends JsonDeserializer<T_fcbaca28c9b37719d07c2ac4> {
            @Override public T_fcbaca28c9b37719d07c2ac4 deserialize(JsonParser p, DeserializationContext c) throws java.io.IOException {
                try { return read(p.getCodec().readTree(p)); }
                catch (RuntimeException e) { throw JsonMappingException.from(p, "SEMANTIC_INPUT", e); }
            }
        }
        public static final class Writer extends JsonSerializer<T_fcbaca28c9b37719d07c2ac4> {
            @Override public void serialize(T_fcbaca28c9b37719d07c2ac4 value, JsonGenerator g, SerializerProvider p) throws java.io.IOException {
                value.write(g);
            }
        }
        private void write(JsonGenerator g) throws java.io.IOException {
            g.writeStartObject(); g.writeObjectField("FLD-CASE-TITLE", v_44b27cbadb64ee9d56f21805); g.writeEndObject();
        }
    }


    @JsonDeserialize(using=T_8adebfa71ac5f294bdeb0801.Reader.class)
    @JsonSerialize(using=T_8adebfa71ac5f294bdeb0801.Writer.class)
    public record T_8adebfa71ac5f294bdeb0801(@JsonProperty("FLD-CASE-TITLE") T_691c513c3054cfe3d0dd758d v_44b27cbadb64ee9d56f21805) {
        public T_8adebfa71ac5f294bdeb0801 {  java.util.Objects.requireNonNull(v_44b27cbadb64ee9d56f21805, "FLD-CASE-TITLE"); }
        public static T_8adebfa71ac5f294bdeb0801 read(JsonNode n) {
            shape(n, java.util.Set.of("FLD-CASE-TITLE"));
            return new T_8adebfa71ac5f294bdeb0801(T_691c513c3054cfe3d0dd758d.read(required(n, "FLD-CASE-TITLE")));
        }
        public static final class Reader extends JsonDeserializer<T_8adebfa71ac5f294bdeb0801> {
            @Override public T_8adebfa71ac5f294bdeb0801 deserialize(JsonParser p, DeserializationContext c) throws java.io.IOException {
                try { return read(p.getCodec().readTree(p)); }
                catch (RuntimeException e) { throw JsonMappingException.from(p, "SEMANTIC_INPUT", e); }
            }
        }
        public static final class Writer extends JsonSerializer<T_8adebfa71ac5f294bdeb0801> {
            @Override public void serialize(T_8adebfa71ac5f294bdeb0801 value, JsonGenerator g, SerializerProvider p) throws java.io.IOException {
                value.write(g);
            }
        }
        private void write(JsonGenerator g) throws java.io.IOException {
            g.writeStartObject(); g.writeObjectField("FLD-CASE-TITLE", v_44b27cbadb64ee9d56f21805); g.writeEndObject();
        }
    }


    @JsonDeserialize(using=T_305cfa7a67e100113cf3b5c1.Reader.class)
    @JsonSerialize(using=T_305cfa7a67e100113cf3b5c1.Writer.class)
    public record T_305cfa7a67e100113cf3b5c1(@JsonProperty("INPUT-TASK-RESOURCE") T_d35114736c127b0a4f015cdeId v_e7b57753ec9f285a96fb2f3e, @JsonProperty("INPUT-TASK-TEXT") String v_347ddac30084d7e07a116384) {
        public T_305cfa7a67e100113cf3b5c1 {   java.util.Objects.requireNonNull(v_e7b57753ec9f285a96fb2f3e, "INPUT-TASK-RESOURCE"); java.util.Objects.requireNonNull(v_347ddac30084d7e07a116384, "INPUT-TASK-TEXT"); if (v_347ddac30084d7e07a116384 != null) validText(v_347ddac30084d7e07a116384); }
        public static T_305cfa7a67e100113cf3b5c1 read(JsonNode n) {
            shape(n, java.util.Set.of("INPUT-TASK-RESOURCE", "INPUT-TASK-TEXT"));
            return new T_305cfa7a67e100113cf3b5c1(new T_d35114736c127b0a4f015cdeId(text(required(n, "INPUT-TASK-RESOURCE"))), text(required(n, "INPUT-TASK-TEXT")));
        }
        public static final class Reader extends JsonDeserializer<T_305cfa7a67e100113cf3b5c1> {
            @Override public T_305cfa7a67e100113cf3b5c1 deserialize(JsonParser p, DeserializationContext c) throws java.io.IOException {
                try { return read(p.getCodec().readTree(p)); }
                catch (RuntimeException e) { throw JsonMappingException.from(p, "SEMANTIC_INPUT", e); }
            }
        }
        public static final class Writer extends JsonSerializer<T_305cfa7a67e100113cf3b5c1> {
            @Override public void serialize(T_305cfa7a67e100113cf3b5c1 value, JsonGenerator g, SerializerProvider p) throws java.io.IOException {
                value.write(g);
            }
        }
        private void write(JsonGenerator g) throws java.io.IOException {
            g.writeStartObject(); g.writeObjectField("INPUT-TASK-RESOURCE", v_e7b57753ec9f285a96fb2f3e); g.writeObjectField("INPUT-TASK-TEXT", v_347ddac30084d7e07a116384); g.writeEndObject();
        }
    }


    @JsonDeserialize(using=T_63ac0912c55a775e2bee74f0.Reader.class)
    @JsonSerialize(using=T_63ac0912c55a775e2bee74f0.Writer.class)
    public record T_63ac0912c55a775e2bee74f0(@JsonProperty("OPERATION-TEXT") String v_deec9bdbe82e43bdd713decc) {
        public T_63ac0912c55a775e2bee74f0 {  java.util.Objects.requireNonNull(v_deec9bdbe82e43bdd713decc, "OPERATION-TEXT"); if (v_deec9bdbe82e43bdd713decc != null) validText(v_deec9bdbe82e43bdd713decc); }
        public static T_63ac0912c55a775e2bee74f0 read(JsonNode n) {
            shape(n, java.util.Set.of("OPERATION-TEXT"));
            return new T_63ac0912c55a775e2bee74f0(text(required(n, "OPERATION-TEXT")));
        }
        public static final class Reader extends JsonDeserializer<T_63ac0912c55a775e2bee74f0> {
            @Override public T_63ac0912c55a775e2bee74f0 deserialize(JsonParser p, DeserializationContext c) throws java.io.IOException {
                try { return read(p.getCodec().readTree(p)); }
                catch (RuntimeException e) { throw JsonMappingException.from(p, "SEMANTIC_INPUT", e); }
            }
        }
        public static final class Writer extends JsonSerializer<T_63ac0912c55a775e2bee74f0> {
            @Override public void serialize(T_63ac0912c55a775e2bee74f0 value, JsonGenerator g, SerializerProvider p) throws java.io.IOException {
                value.write(g);
            }
        }
        private void write(JsonGenerator g) throws java.io.IOException {
            g.writeStartObject(); g.writeObjectField("OPERATION-TEXT", v_deec9bdbe82e43bdd713decc); g.writeEndObject();
        }
    }


    @JsonDeserialize(using=T_781a0c95aa44b66be234c99e.Reader.class)
    @JsonSerialize(using=T_781a0c95aa44b66be234c99e.Writer.class)
    public record T_781a0c95aa44b66be234c99e(@JsonProperty("RESULT-TEXT") String v_76ef0afed24f454088596039) {
        public T_781a0c95aa44b66be234c99e {  java.util.Objects.requireNonNull(v_76ef0afed24f454088596039, "RESULT-TEXT"); if (v_76ef0afed24f454088596039 != null) validText(v_76ef0afed24f454088596039); }
        public static T_781a0c95aa44b66be234c99e read(JsonNode n) {
            shape(n, java.util.Set.of("RESULT-TEXT"));
            return new T_781a0c95aa44b66be234c99e(text(required(n, "RESULT-TEXT")));
        }
        public static final class Reader extends JsonDeserializer<T_781a0c95aa44b66be234c99e> {
            @Override public T_781a0c95aa44b66be234c99e deserialize(JsonParser p, DeserializationContext c) throws java.io.IOException {
                try { return read(p.getCodec().readTree(p)); }
                catch (RuntimeException e) { throw JsonMappingException.from(p, "SEMANTIC_INPUT", e); }
            }
        }
        public static final class Writer extends JsonSerializer<T_781a0c95aa44b66be234c99e> {
            @Override public void serialize(T_781a0c95aa44b66be234c99e value, JsonGenerator g, SerializerProvider p) throws java.io.IOException {
                value.write(g);
            }
        }
        private void write(JsonGenerator g) throws java.io.IOException {
            g.writeStartObject(); g.writeObjectField("RESULT-TEXT", v_76ef0afed24f454088596039); g.writeEndObject();
        }
    }


    @JsonDeserialize(using=T_0e6739cd5c48f9356c70c968.Reader.class)
    @JsonSerialize(using=T_0e6739cd5c48f9356c70c968.Writer.class)
    public record T_0e6739cd5c48f9356c70c968(@JsonProperty("ORG-ID") T_0e6739cd5c48f9356c70c968Id v_68c58c7f147359be3f4b386a) {
        public T_0e6739cd5c48f9356c70c968 {  java.util.Objects.requireNonNull(v_68c58c7f147359be3f4b386a, "ORG-ID"); }
        public static T_0e6739cd5c48f9356c70c968 read(JsonNode n) {
            shape(n, java.util.Set.of("ORG-ID"));
            return new T_0e6739cd5c48f9356c70c968(new T_0e6739cd5c48f9356c70c968Id(text(required(n, "ORG-ID"))));
        }
        public static final class Reader extends JsonDeserializer<T_0e6739cd5c48f9356c70c968> {
            @Override public T_0e6739cd5c48f9356c70c968 deserialize(JsonParser p, DeserializationContext c) throws java.io.IOException {
                try { return read(p.getCodec().readTree(p)); }
                catch (RuntimeException e) { throw JsonMappingException.from(p, "SEMANTIC_INPUT", e); }
            }
        }
        public static final class Writer extends JsonSerializer<T_0e6739cd5c48f9356c70c968> {
            @Override public void serialize(T_0e6739cd5c48f9356c70c968 value, JsonGenerator g, SerializerProvider p) throws java.io.IOException {
                value.write(g);
            }
        }
        private void write(JsonGenerator g) throws java.io.IOException {
            g.writeStartObject(); g.writeObjectField("ORG-ID", v_68c58c7f147359be3f4b386a); g.writeEndObject();
        }
    }

public record T_0e6739cd5c48f9356c70c968Id(@JsonValue String value) { @JsonCreator(mode=JsonCreator.Mode.DELEGATING) public T_0e6739cd5c48f9356c70c968Id { validText(value); if (blankIdentity(value)) throw new IllegalArgumentException("EMPTY_IDENTITY"); } }

    @JsonDeserialize(using=T_e83d48b36740f933d67f64d0.Reader.class)
    @JsonSerialize(using=T_e83d48b36740f933d67f64d0.Writer.class)
    public record T_e83d48b36740f933d67f64d0(@JsonProperty("OUTPUT-TASK-TEXT") String v_dd38e57e1fff01860a1d756d) {
        public T_e83d48b36740f933d67f64d0 {  java.util.Objects.requireNonNull(v_dd38e57e1fff01860a1d756d, "OUTPUT-TASK-TEXT"); if (v_dd38e57e1fff01860a1d756d != null) validText(v_dd38e57e1fff01860a1d756d); }
        public static T_e83d48b36740f933d67f64d0 read(JsonNode n) {
            shape(n, java.util.Set.of("OUTPUT-TASK-TEXT"));
            return new T_e83d48b36740f933d67f64d0(text(required(n, "OUTPUT-TASK-TEXT")));
        }
        public static final class Reader extends JsonDeserializer<T_e83d48b36740f933d67f64d0> {
            @Override public T_e83d48b36740f933d67f64d0 deserialize(JsonParser p, DeserializationContext c) throws java.io.IOException {
                try { return read(p.getCodec().readTree(p)); }
                catch (RuntimeException e) { throw JsonMappingException.from(p, "SEMANTIC_INPUT", e); }
            }
        }
        public static final class Writer extends JsonSerializer<T_e83d48b36740f933d67f64d0> {
            @Override public void serialize(T_e83d48b36740f933d67f64d0 value, JsonGenerator g, SerializerProvider p) throws java.io.IOException {
                value.write(g);
            }
        }
        private void write(JsonGenerator g) throws java.io.IOException {
            g.writeStartObject(); g.writeObjectField("OUTPUT-TASK-TEXT", v_dd38e57e1fff01860a1d756d); g.writeEndObject();
        }
    }


    @JsonDeserialize(using=T_73ec76bc5a3273ce8251ca7c.Reader.class)
    @JsonSerialize(using=T_73ec76bc5a3273ce8251ca7c.Writer.class)
    public record T_73ec76bc5a3273ce8251ca7c(@JsonProperty("QUERY-TEXT") String v_d456657b12367788740f9907) {
        public T_73ec76bc5a3273ce8251ca7c {  java.util.Objects.requireNonNull(v_d456657b12367788740f9907, "QUERY-TEXT"); if (v_d456657b12367788740f9907 != null) validText(v_d456657b12367788740f9907); }
        public static T_73ec76bc5a3273ce8251ca7c read(JsonNode n) {
            shape(n, java.util.Set.of("QUERY-TEXT"));
            return new T_73ec76bc5a3273ce8251ca7c(text(required(n, "QUERY-TEXT")));
        }
        public static final class Reader extends JsonDeserializer<T_73ec76bc5a3273ce8251ca7c> {
            @Override public T_73ec76bc5a3273ce8251ca7c deserialize(JsonParser p, DeserializationContext c) throws java.io.IOException {
                try { return read(p.getCodec().readTree(p)); }
                catch (RuntimeException e) { throw JsonMappingException.from(p, "SEMANTIC_INPUT", e); }
            }
        }
        public static final class Writer extends JsonSerializer<T_73ec76bc5a3273ce8251ca7c> {
            @Override public void serialize(T_73ec76bc5a3273ce8251ca7c value, JsonGenerator g, SerializerProvider p) throws java.io.IOException {
                value.write(g);
            }
        }
        private void write(JsonGenerator g) throws java.io.IOException {
            g.writeStartObject(); g.writeObjectField("QUERY-TEXT", v_d456657b12367788740f9907); g.writeEndObject();
        }
    }


    @JsonDeserialize(using=T_182e499256bea391f0891e85.Reader.class)
    @JsonSerialize(using=T_182e499256bea391f0891e85.Writer.class)
    public record T_182e499256bea391f0891e85(@JsonProperty("REVIEW-ID") T_182e499256bea391f0891e85Id v_e8e7747edf9a67aafd17c3ca, @JsonProperty("REVIEW-TENANT") T_0e6739cd5c48f9356c70c968Id v_7ec165e90736f20df7c5ac17, @JsonProperty("REVIEW-outcome") String v_78b0e06e87c3572ac3c3c72b) {
        public T_182e499256bea391f0891e85 {    java.util.Objects.requireNonNull(v_e8e7747edf9a67aafd17c3ca, "REVIEW-ID"); java.util.Objects.requireNonNull(v_7ec165e90736f20df7c5ac17, "REVIEW-TENANT"); java.util.Objects.requireNonNull(v_78b0e06e87c3572ac3c3c72b, "REVIEW-outcome"); if (v_78b0e06e87c3572ac3c3c72b != null) validText(v_78b0e06e87c3572ac3c3c72b); }
        public static T_182e499256bea391f0891e85 read(JsonNode n) {
            shape(n, java.util.Set.of("REVIEW-ID", "REVIEW-TENANT", "REVIEW-outcome"));
            return new T_182e499256bea391f0891e85(new T_182e499256bea391f0891e85Id(text(required(n, "REVIEW-ID"))), new T_0e6739cd5c48f9356c70c968Id(text(required(n, "REVIEW-TENANT"))), text(required(n, "REVIEW-outcome")));
        }
        public static final class Reader extends JsonDeserializer<T_182e499256bea391f0891e85> {
            @Override public T_182e499256bea391f0891e85 deserialize(JsonParser p, DeserializationContext c) throws java.io.IOException {
                try { return read(p.getCodec().readTree(p)); }
                catch (RuntimeException e) { throw JsonMappingException.from(p, "SEMANTIC_INPUT", e); }
            }
        }
        public static final class Writer extends JsonSerializer<T_182e499256bea391f0891e85> {
            @Override public void serialize(T_182e499256bea391f0891e85 value, JsonGenerator g, SerializerProvider p) throws java.io.IOException {
                value.write(g);
            }
        }
        private void write(JsonGenerator g) throws java.io.IOException {
            g.writeStartObject(); g.writeObjectField("REVIEW-ID", v_e8e7747edf9a67aafd17c3ca); g.writeObjectField("REVIEW-TENANT", v_7ec165e90736f20df7c5ac17); g.writeObjectField("REVIEW-outcome", v_78b0e06e87c3572ac3c3c72b); g.writeEndObject();
        }
    }

public record T_182e499256bea391f0891e85Id(@JsonValue String value) { @JsonCreator(mode=JsonCreator.Mode.DELEGATING) public T_182e499256bea391f0891e85Id { validText(value); if (blankIdentity(value)) throw new IllegalArgumentException("EMPTY_IDENTITY"); } }
public record T_adb2aeb4b3fe6200489b7551(@JsonValue String value) { public T_adb2aeb4b3fe6200489b7551 { java.util.Objects.requireNonNull(value); validText(value); if (value.codePointCount(0,value.length()) < 1 || value.codePointCount(0,value.length()) > 40) throw new IllegalArgumentException("REFINEMENT"); } public static T_adb2aeb4b3fe6200489b7551 read(JsonNode n) { return new T_adb2aeb4b3fe6200489b7551(text(n)); } }

    @JsonDeserialize(using=T_92b7b421992ef490f3b75898.Reader.class)
    @JsonSerialize(using=T_92b7b421992ef490f3b75898.Writer.class)
    public record T_92b7b421992ef490f3b75898(@JsonProperty("USER-ID") T_92b7b421992ef490f3b75898Id v_8cdd520f7d3d409ff608ae27, @JsonProperty("USER-TENANT") T_0e6739cd5c48f9356c70c968Id v_4880a1ae752d8f5fc59008f6) {
        public T_92b7b421992ef490f3b75898 {   java.util.Objects.requireNonNull(v_8cdd520f7d3d409ff608ae27, "USER-ID"); java.util.Objects.requireNonNull(v_4880a1ae752d8f5fc59008f6, "USER-TENANT"); }
        public static T_92b7b421992ef490f3b75898 read(JsonNode n) {
            shape(n, java.util.Set.of("USER-ID", "USER-TENANT"));
            return new T_92b7b421992ef490f3b75898(new T_92b7b421992ef490f3b75898Id(text(required(n, "USER-ID"))), new T_0e6739cd5c48f9356c70c968Id(text(required(n, "USER-TENANT"))));
        }
        public static final class Reader extends JsonDeserializer<T_92b7b421992ef490f3b75898> {
            @Override public T_92b7b421992ef490f3b75898 deserialize(JsonParser p, DeserializationContext c) throws java.io.IOException {
                try { return read(p.getCodec().readTree(p)); }
                catch (RuntimeException e) { throw JsonMappingException.from(p, "SEMANTIC_INPUT", e); }
            }
        }
        public static final class Writer extends JsonSerializer<T_92b7b421992ef490f3b75898> {
            @Override public void serialize(T_92b7b421992ef490f3b75898 value, JsonGenerator g, SerializerProvider p) throws java.io.IOException {
                value.write(g);
            }
        }
        private void write(JsonGenerator g) throws java.io.IOException {
            g.writeStartObject(); g.writeObjectField("USER-ID", v_8cdd520f7d3d409ff608ae27); g.writeObjectField("USER-TENANT", v_4880a1ae752d8f5fc59008f6); g.writeEndObject();
        }
    }

public record T_92b7b421992ef490f3b75898Id(@JsonValue String value) { @JsonCreator(mode=JsonCreator.Mode.DELEGATING) public T_92b7b421992ef490f3b75898Id { validText(value); if (blankIdentity(value)) throw new IllegalArgumentException("EMPTY_IDENTITY"); } }

    @JsonDeserialize(using=T_691c513c3054cfe3d0dd758d.Reader.class)
    @JsonSerialize(using=T_691c513c3054cfe3d0dd758d.Writer.class)
    public record T_691c513c3054cfe3d0dd758d(@JsonProperty("FLD-TITLE") String v_bfbbba1d4eb56eff611964a6) {
        public T_691c513c3054cfe3d0dd758d {  java.util.Objects.requireNonNull(v_bfbbba1d4eb56eff611964a6, "FLD-TITLE"); if (v_bfbbba1d4eb56eff611964a6 != null) validText(v_bfbbba1d4eb56eff611964a6); }
        public static T_691c513c3054cfe3d0dd758d read(JsonNode n) {
            shape(n, java.util.Set.of("FLD-TITLE"));
            return new T_691c513c3054cfe3d0dd758d(text(required(n, "FLD-TITLE")));
        }
        public static final class Reader extends JsonDeserializer<T_691c513c3054cfe3d0dd758d> {
            @Override public T_691c513c3054cfe3d0dd758d deserialize(JsonParser p, DeserializationContext c) throws java.io.IOException {
                try { return read(p.getCodec().readTree(p)); }
                catch (RuntimeException e) { throw JsonMappingException.from(p, "SEMANTIC_INPUT", e); }
            }
        }
        public static final class Writer extends JsonSerializer<T_691c513c3054cfe3d0dd758d> {
            @Override public void serialize(T_691c513c3054cfe3d0dd758d value, JsonGenerator g, SerializerProvider p) throws java.io.IOException {
                value.write(g);
            }
        }
        private void write(JsonGenerator g) throws java.io.IOException {
            g.writeStartObject(); g.writeObjectField("FLD-TITLE", v_bfbbba1d4eb56eff611964a6); g.writeEndObject();
        }
    }

}
