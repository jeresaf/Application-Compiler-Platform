package acp.generated;
import static acp.generated.Contracts.*;
import acp.infrastructure.ExecutionStore;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
@RestController
public final class TypedController {
    public static final class StringKey extends com.fasterxml.jackson.databind.JsonDeserializer<String> {
        @Override public String deserialize(com.fasterxml.jackson.core.JsonParser parser, com.fasterxml.jackson.databind.DeserializationContext context) throws java.io.IOException {
            if(parser.currentToken()!=com.fasterxml.jackson.core.JsonToken.VALUE_STRING) throw new IllegalArgumentException("IDEMPOTENCY_KEY_TYPE");
            String value=parser.getText(); ExecutionStore.bytes(value); return value;
        }
    }
    private final Invocations tasks;
    public TypedController(Invocations tasks) { this.tasks=tasks; }
public record T_00053c8b9b23094950bcfccaRequest(T_d35114736c127b0a4f015cdeId resourceId, long expectedVersion, @com.fasterxml.jackson.databind.annotation.JsonDeserialize(using=StringKey.class) String idempotencyKey, T_63ac0912c55a775e2bee74f0 input) {
        public T_00053c8b9b23094950bcfccaRequest { java.util.Objects.requireNonNull(input); if (expectedVersion<0) throw new IllegalArgumentException("VERSION"); }
    }
    @PostMapping("/api/op_00053c8b9b23094950bcfcca")
    public ExecutionStore.Completion<T_781a0c95aa44b66be234c99e> v_00053c8b9b23094950bcfcca(@RequestBody T_00053c8b9b23094950bcfccaRequest request, @AuthenticationPrincipal Jwt jwt) {
        return tasks.v_00053c8b9b23094950bcfcca(request.resourceId(), request.expectedVersion(), request.input(), request.idempotencyKey(), jwt);
    }
public record T_87560a4e6170ba4f56c8c3daRequest(T_d35114736c127b0a4f015cdeId resourceId, long expectedVersion, @com.fasterxml.jackson.databind.annotation.JsonDeserialize(using=StringKey.class) String idempotencyKey, T_63ac0912c55a775e2bee74f0 input) {
        public T_87560a4e6170ba4f56c8c3daRequest { java.util.Objects.requireNonNull(input); if (expectedVersion<0) throw new IllegalArgumentException("VERSION"); }
    }
    @PostMapping("/api/op_87560a4e6170ba4f56c8c3da")
    public ExecutionStore.Completion<T_781a0c95aa44b66be234c99e> v_87560a4e6170ba4f56c8c3da(@RequestBody T_87560a4e6170ba4f56c8c3daRequest request, @AuthenticationPrincipal Jwt jwt) {
        return tasks.v_87560a4e6170ba4f56c8c3da(request.resourceId(), request.expectedVersion(), request.input(), request.idempotencyKey(), jwt);
    }
public record T_3b41c83fea2a261fa43d6655Request(T_d35114736c127b0a4f015cdeId resourceId, long expectedVersion, @com.fasterxml.jackson.databind.annotation.JsonDeserialize(using=StringKey.class) String idempotencyKey, T_63ac0912c55a775e2bee74f0 input) {
        public T_3b41c83fea2a261fa43d6655Request { java.util.Objects.requireNonNull(input); if (expectedVersion<0) throw new IllegalArgumentException("VERSION"); }
    }
    @PostMapping("/api/op_3b41c83fea2a261fa43d6655")
    public ExecutionStore.Completion<T_781a0c95aa44b66be234c99e> v_3b41c83fea2a261fa43d6655(@RequestBody T_3b41c83fea2a261fa43d6655Request request, @AuthenticationPrincipal Jwt jwt) {
        return tasks.v_3b41c83fea2a261fa43d6655(request.resourceId(), request.expectedVersion(), request.input(), request.idempotencyKey(), jwt);
    }
@PostMapping("/api/op_647d32adf46be996dd32e08b")
    public java.util.List<ExecutionStore.Completion<T_e83d48b36740f933d67f64d0>> v_647d32adf46be996dd32e08b(@RequestBody T_73ec76bc5a3273ce8251ca7c input, @RequestParam(defaultValue="0") int offset, @RequestParam(defaultValue="25") int limit, @AuthenticationPrincipal Jwt jwt) {
        return tasks.v_647d32adf46be996dd32e08b(input, offset, limit, jwt);
    }
public record T_225e20f12f0b359413f7a725Request(long expectedVersion, @com.fasterxml.jackson.databind.annotation.JsonDeserialize(using=StringKey.class) String idempotencyKey, T_305cfa7a67e100113cf3b5c1 input) {
        public T_225e20f12f0b359413f7a725Request { java.util.Objects.requireNonNull(input); if (expectedVersion<0) throw new IllegalArgumentException("VERSION"); }
    }
    @PostMapping("/api/op_225e20f12f0b359413f7a725")
    public ExecutionStore.Completion<T_e83d48b36740f933d67f64d0> v_225e20f12f0b359413f7a725(@RequestBody T_225e20f12f0b359413f7a725Request request, @AuthenticationPrincipal Jwt jwt) {
        return tasks.v_225e20f12f0b359413f7a725(request.expectedVersion(), request.input(), request.idempotencyKey(), jwt);
    }
}
