package acp.generated;
import static acp.generated.Contracts.*;
import acp.infrastructure.*;
import org.springframework.security.oauth2.jwt.Jwt;
/** Compiled exact disposal effects and complete staged WRITE invariant checks. */
public final class LifecycleActions implements LifecycleRuntime.Actions {
 private final ExecutionStore store;
 public LifecycleActions(ExecutionStore store){this.store=store;}
 public LifecycleRuntime.Snapshot lock(String lifecycle,String resource,Jwt jwt){return switch(lifecycle){case "LIFECYCLE-ENT-PAYMENT" -> { var row=store.lock("e_2f6d38b95ca9030968971abd","f_8306508e7c606f32081c13bb","f_55326825932184ca370c199a",resource,jwt,(rs, rowIndex) -> new ExecutionStore.Row<>(new T_2f6d38b95ca9030968971abd(new Da912bf8c8345dd6fbf51c477(rs.getBigDecimal("f_ce4f5e6c05433529cf6a3cbb")),new T_2f6d38b95ca9030968971abdId(ExecutionStore.text(rs.getBytes("f_8306508e7c606f32081c13bb"))),new T_47560209428de42ddef6e4efId(ExecutionStore.text(rs.getBytes("f_55326825932184ca370c199a"))),ExecutionStore.text(rs.getBytes("f_a3c92c5b2195fe53206f71ca"))), rs.getLong("acp_version"), rs.getString("acp_state"))); yield new LifecycleRuntime.Snapshot(ExecutionStore.semantic(new Object[]{"FLD-AMOUNT", row.value().v_ce4f5e6c05433529cf6a3cbb()},new Object[]{"FLD-PAYMENT-ID", row.value().v_8306508e7c606f32081c13bb()},new Object[]{"FLD-PAYMENT-TENANT", row.value().v_55326825932184ca370c199a()},new Object[]{"FLD-TASK-SUMMARY", row.value().v_a3c92c5b2195fe53206f71ca()}),row.version(),row.state()); } default -> throw new IllegalArgumentException("LIFECYCLE_REQUIRED");};}
 public void apply(String lifecycle,String resource,Jwt jwt){switch(lifecycle){case "LIFECYCLE-ENT-PAYMENT" -> {var row=store.lock("e_2f6d38b95ca9030968971abd","f_8306508e7c606f32081c13bb","f_55326825932184ca370c199a",resource,jwt,(rs, rowIndex) -> new ExecutionStore.Row<>(new T_2f6d38b95ca9030968971abd(new Da912bf8c8345dd6fbf51c477(rs.getBigDecimal("f_ce4f5e6c05433529cf6a3cbb")),new T_2f6d38b95ca9030968971abdId(ExecutionStore.text(rs.getBytes("f_8306508e7c606f32081c13bb"))),new T_47560209428de42ddef6e4efId(ExecutionStore.text(rs.getBytes("f_55326825932184ca370c199a"))),ExecutionStore.text(rs.getBytes("f_a3c92c5b2195fe53206f71ca"))), rs.getLong("acp_version"), rs.getString("acp_state")));
var staged=row.value();
staged=new T_2f6d38b95ca9030968971abd(new Da912bf8c8345dd6fbf51c477(new java.math.BigDecimal("1")),staged.v_8306508e7c606f32081c13bb(),staged.v_55326825932184ca370c199a(),staged.v_a3c92c5b2195fe53206f71ca());
if(!Boolean.TRUE.equals((ExecutionStore.number(staged.v_ce4f5e6c05433529cf6a3cbb()).compareTo(ExecutionStore.number(new Da912bf8c8345dd6fbf51c477(new java.math.BigDecimal("0")))) > 0)))throw new IllegalArgumentException("POST_DISPOSAL_INVARIANT");
store.update("UPDATE e_2f6d38b95ca9030968971abd SET f_ce4f5e6c05433529cf6a3cbb=?,acp_version=acp_version+1 WHERE f_8306508e7c606f32081c13bb=? AND f_55326825932184ca370c199a=? AND acp_version=?",staged.v_ce4f5e6c05433529cf6a3cbb().value(),ExecutionStore.bytes(resource),ExecutionStore.bytes(jwt.getClaimAsString("tenant")),row.version());
store.audit("LIFECYCLE-ENT-PAYMENT",resource,jwt);
store.classifiedAudit("LIFECYCLE-ENT-PAYMENT", resource, "WRITE", new String[]{"FLD-AMOUNT"}, jwt);} default -> throw new IllegalArgumentException("LIFECYCLE_REQUIRED");}}
}
