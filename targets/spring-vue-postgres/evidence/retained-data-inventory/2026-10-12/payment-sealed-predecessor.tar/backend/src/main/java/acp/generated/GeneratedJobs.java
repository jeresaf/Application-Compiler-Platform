package acp.generated;
import static acp.generated.Contracts.*;
import acp.infrastructure.*;
import java.util.*;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.oauth2.jwt.Jwt;
/** Exact canonical Job input bindings; caller supplies trusted configured principal. */
public final class GeneratedJobs implements JobRuntime.Invocation {
 private final JdbcTemplate jdbc;private final Invocations invocations;
 public GeneratedJobs(JdbcTemplate jdbc,Invocations invocations){this.jdbc=jdbc;this.invocations=invocations;}
 public Object execute(String job,String occurrence,Jwt jwt){return switch(job){
case "JOB-TASK" -> {var input=new T_305cfa7a67e100113cf3b5c1(new T_2f6d38b95ca9030968971abdId("fixture-resource"), "Explicit scheduled fixture text");long version=jdbc.queryForObject("SELECT acp_version FROM e_2f6d38b95ca9030968971abd WHERE f_8306508e7c606f32081c13bb=? AND f_55326825932184ca370c199a=?",Long.class,ExecutionStore.bytes("fixture-resource"),ExecutionStore.bytes(jwt.getClaimAsString("tenant")));yield invocations.v_225e20f12f0b359413f7a725(version,input,occurrence,jwt,"RETRY-TASK");}
 default -> throw new IllegalArgumentException("UNKNOWN_JOB");};}
}
