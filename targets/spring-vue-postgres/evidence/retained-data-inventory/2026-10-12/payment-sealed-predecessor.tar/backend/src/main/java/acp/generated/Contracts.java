package acp.generated;
import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.core.*;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.annotation.*;

/** Generated from exact semantic origins. No map-shaped operation contracts. */
public final class Contracts {
    private Contracts() {}
    public record Slot<T>(boolean present, T value) {
        public Slot { if (!present && value != null) throw new IllegalArgumentException("ABSENT_VALUE"); }
        public static <T> Slot<T> absent() { return new Slot<>(false, null); }
        public static <T> Slot<T> of(T value) { return new Slot<>(true, value); }
    }
    static void shape(JsonNode n, java.util.Set<String> allowed) {
        if (n == null || !n.isObject()) throw new IllegalArgumentException("OBJECT_REQUIRED");
        n.fieldNames().forEachRemaining(k -> { if (!allowed.contains(k)) throw new IllegalArgumentException("UNKNOWN_MEMBER"); });
    }
    static JsonNode required(JsonNode n, String key) { if (!n.has(key)) throw new IllegalArgumentException("REQUIRED_INPUT:" + key); return n.get(key); }
    static boolean blankIdentity(String s) { return s.codePoints().allMatch(cp -> Character.isWhitespace(cp) || Character.isSpaceChar(cp) || cp == 0x85); }
    static void validText(String s) {
        java.util.Objects.requireNonNull(s);
        for (int i=0;i<s.length();i++) {
            char c=s.charAt(i);
            if (Character.isHighSurrogate(c)) { if (++i>=s.length() || !Character.isLowSurrogate(s.charAt(i))) throw new IllegalArgumentException("UNICODE_SCALAR"); }
            else if (Character.isLowSurrogate(c)) throw new IllegalArgumentException("UNICODE_SCALAR");
        }
    }
    static String text(JsonNode n) { if (n == null || !n.isTextual()) throw new IllegalArgumentException("STRING_REQUIRED"); String s=n.textValue(); validText(s); return s; }
    static Boolean bool(JsonNode n) { if (n == null || !n.isBoolean()) throw new IllegalArgumentException("BOOLEAN_REQUIRED"); return n.booleanValue(); }
    static java.math.BigDecimal decimal(JsonNode n) {
        String s=text(n);
        if (s.length()>128 || !s.matches("-?(0|[1-9][0-9]*)(\\.[0-9]+)?")) throw new IllegalArgumentException("DECIMAL_REPRESENTATION");
        return new java.math.BigDecimal(s);
    }
    static Long integer(JsonNode n) { if (n == null || !n.isIntegralNumber() || !n.canConvertToLong()) throw new IllegalArgumentException("INTEGER_REQUIRED"); return n.longValue(); }

    @JsonDeserialize(using=T_52ec36081d245a500ce7f793.Reader.class)
    @JsonSerialize(using=T_52ec36081d245a500ce7f793.Writer.class)
    public record T_52ec36081d245a500ce7f793(@JsonProperty("FLD-MEMBER-ID") T_52ec36081d245a500ce7f793Id v_5601399494015f9997f1279c, @JsonProperty("FLD-MEMBER-TENANT") T_47560209428de42ddef6e4efId v_db1033babd768a7d95553905) {
        public T_52ec36081d245a500ce7f793 {   java.util.Objects.requireNonNull(v_5601399494015f9997f1279c, "FLD-MEMBER-ID"); java.util.Objects.requireNonNull(v_db1033babd768a7d95553905, "FLD-MEMBER-TENANT"); }
        public static T_52ec36081d245a500ce7f793 read(JsonNode n) {
            shape(n, java.util.Set.of("FLD-MEMBER-ID", "FLD-MEMBER-TENANT"));
            return new T_52ec36081d245a500ce7f793(new T_52ec36081d245a500ce7f793Id(text(required(n, "FLD-MEMBER-ID"))), new T_47560209428de42ddef6e4efId(text(required(n, "FLD-MEMBER-TENANT"))));
        }
        public static final class Reader extends JsonDeserializer<T_52ec36081d245a500ce7f793> {
            @Override public T_52ec36081d245a500ce7f793 deserialize(JsonParser p, DeserializationContext c) throws java.io.IOException {
                try { return read(p.getCodec().readTree(p)); }
                catch (RuntimeException e) { throw JsonMappingException.from(p, "SEMANTIC_INPUT", e); }
            }
        }
        public static final class Writer extends JsonSerializer<T_52ec36081d245a500ce7f793> {
            @Override public void serialize(T_52ec36081d245a500ce7f793 value, JsonGenerator g, SerializerProvider p) throws java.io.IOException {
                value.write(g);
            }
        }
        private void write(JsonGenerator g) throws java.io.IOException {
            g.writeStartObject(); g.writeObjectField("FLD-MEMBER-ID", v_5601399494015f9997f1279c); g.writeObjectField("FLD-MEMBER-TENANT", v_db1033babd768a7d95553905); g.writeEndObject();
        }
    }

public record T_52ec36081d245a500ce7f793Id(@JsonValue String value) { @JsonCreator(mode=JsonCreator.Mode.DELEGATING) public T_52ec36081d245a500ce7f793Id { validText(value); if (blankIdentity(value)) throw new IllegalArgumentException("EMPTY_IDENTITY"); } }

    @JsonDeserialize(using=T_2f6d38b95ca9030968971abd.Reader.class)
    @JsonSerialize(using=T_2f6d38b95ca9030968971abd.Writer.class)
    public record T_2f6d38b95ca9030968971abd(@JsonProperty("FLD-AMOUNT") Da912bf8c8345dd6fbf51c477 v_ce4f5e6c05433529cf6a3cbb, @JsonProperty("FLD-PAYMENT-ID") T_2f6d38b95ca9030968971abdId v_8306508e7c606f32081c13bb, @JsonProperty("FLD-PAYMENT-TENANT") T_47560209428de42ddef6e4efId v_55326825932184ca370c199a, @JsonProperty("FLD-TASK-SUMMARY") String v_a3c92c5b2195fe53206f71ca) {
        public T_2f6d38b95ca9030968971abd {     java.util.Objects.requireNonNull(v_ce4f5e6c05433529cf6a3cbb, "FLD-AMOUNT"); java.util.Objects.requireNonNull(v_8306508e7c606f32081c13bb, "FLD-PAYMENT-ID"); java.util.Objects.requireNonNull(v_55326825932184ca370c199a, "FLD-PAYMENT-TENANT"); java.util.Objects.requireNonNull(v_a3c92c5b2195fe53206f71ca, "FLD-TASK-SUMMARY"); if (v_a3c92c5b2195fe53206f71ca != null) validText(v_a3c92c5b2195fe53206f71ca); }
        public static T_2f6d38b95ca9030968971abd read(JsonNode n) {
            shape(n, java.util.Set.of("FLD-AMOUNT", "FLD-PAYMENT-ID", "FLD-PAYMENT-TENANT", "FLD-TASK-SUMMARY"));
            return new T_2f6d38b95ca9030968971abd(new Da912bf8c8345dd6fbf51c477(decimal(required(n, "FLD-AMOUNT"))), new T_2f6d38b95ca9030968971abdId(text(required(n, "FLD-PAYMENT-ID"))), new T_47560209428de42ddef6e4efId(text(required(n, "FLD-PAYMENT-TENANT"))), text(required(n, "FLD-TASK-SUMMARY")));
        }
        public static final class Reader extends JsonDeserializer<T_2f6d38b95ca9030968971abd> {
            @Override public T_2f6d38b95ca9030968971abd deserialize(JsonParser p, DeserializationContext c) throws java.io.IOException {
                try { return read(p.getCodec().readTree(p)); }
                catch (RuntimeException e) { throw JsonMappingException.from(p, "SEMANTIC_INPUT", e); }
            }
        }
        public static final class Writer extends JsonSerializer<T_2f6d38b95ca9030968971abd> {
            @Override public void serialize(T_2f6d38b95ca9030968971abd value, JsonGenerator g, SerializerProvider p) throws java.io.IOException {
                value.write(g);
            }
        }
        private void write(JsonGenerator g) throws java.io.IOException {
            g.writeStartObject(); g.writeObjectField("FLD-AMOUNT", v_ce4f5e6c05433529cf6a3cbb); g.writeObjectField("FLD-PAYMENT-ID", v_8306508e7c606f32081c13bb); g.writeObjectField("FLD-PAYMENT-TENANT", v_55326825932184ca370c199a); g.writeObjectField("FLD-TASK-SUMMARY", v_a3c92c5b2195fe53206f71ca); g.writeEndObject();
        }
    }

public record T_2f6d38b95ca9030968971abdId(@JsonValue String value) { @JsonCreator(mode=JsonCreator.Mode.DELEGATING) public T_2f6d38b95ca9030968971abdId { validText(value); if (blankIdentity(value)) throw new IllegalArgumentException("EMPTY_IDENTITY"); } }

    @JsonDeserialize(using=T_47560209428de42ddef6e4ef.Reader.class)
    @JsonSerialize(using=T_47560209428de42ddef6e4ef.Writer.class)
    public record T_47560209428de42ddef6e4ef(@JsonProperty("FLD-TENANT-ID") T_47560209428de42ddef6e4efId v_4030c1b112c7ddba35dca3cf) {
        public T_47560209428de42ddef6e4ef {  java.util.Objects.requireNonNull(v_4030c1b112c7ddba35dca3cf, "FLD-TENANT-ID"); }
        public static T_47560209428de42ddef6e4ef read(JsonNode n) {
            shape(n, java.util.Set.of("FLD-TENANT-ID"));
            return new T_47560209428de42ddef6e4ef(new T_47560209428de42ddef6e4efId(text(required(n, "FLD-TENANT-ID"))));
        }
        public static final class Reader extends JsonDeserializer<T_47560209428de42ddef6e4ef> {
            @Override public T_47560209428de42ddef6e4ef deserialize(JsonParser p, DeserializationContext c) throws java.io.IOException {
                try { return read(p.getCodec().readTree(p)); }
                catch (RuntimeException e) { throw JsonMappingException.from(p, "SEMANTIC_INPUT", e); }
            }
        }
        public static final class Writer extends JsonSerializer<T_47560209428de42ddef6e4ef> {
            @Override public void serialize(T_47560209428de42ddef6e4ef value, JsonGenerator g, SerializerProvider p) throws java.io.IOException {
                value.write(g);
            }
        }
        private void write(JsonGenerator g) throws java.io.IOException {
            g.writeStartObject(); g.writeObjectField("FLD-TENANT-ID", v_4030c1b112c7ddba35dca3cf); g.writeEndObject();
        }
    }

public record T_47560209428de42ddef6e4efId(@JsonValue String value) { @JsonCreator(mode=JsonCreator.Mode.DELEGATING) public T_47560209428de42ddef6e4efId { validText(value); if (blankIdentity(value)) throw new IllegalArgumentException("EMPTY_IDENTITY"); } }

    @JsonDeserialize(using=T_dd75a52d7f274b3099c6c2e8.Reader.class)
    @JsonSerialize(using=T_dd75a52d7f274b3099c6c2e8.Writer.class)
    public record T_dd75a52d7f274b3099c6c2e8(@JsonProperty("FLD-AMOUNT") Da912bf8c8345dd6fbf51c477 v_ce4f5e6c05433529cf6a3cbb) {
        public T_dd75a52d7f274b3099c6c2e8 {  java.util.Objects.requireNonNull(v_ce4f5e6c05433529cf6a3cbb, "FLD-AMOUNT"); }
        public static T_dd75a52d7f274b3099c6c2e8 read(JsonNode n) {
            shape(n, java.util.Set.of("FLD-AMOUNT"));
            return new T_dd75a52d7f274b3099c6c2e8(new Da912bf8c8345dd6fbf51c477(decimal(required(n, "FLD-AMOUNT"))));
        }
        public static final class Reader extends JsonDeserializer<T_dd75a52d7f274b3099c6c2e8> {
            @Override public T_dd75a52d7f274b3099c6c2e8 deserialize(JsonParser p, DeserializationContext c) throws java.io.IOException {
                try { return read(p.getCodec().readTree(p)); }
                catch (RuntimeException e) { throw JsonMappingException.from(p, "SEMANTIC_INPUT", e); }
            }
        }
        public static final class Writer extends JsonSerializer<T_dd75a52d7f274b3099c6c2e8> {
            @Override public void serialize(T_dd75a52d7f274b3099c6c2e8 value, JsonGenerator g, SerializerProvider p) throws java.io.IOException {
                value.write(g);
            }
        }
        private void write(JsonGenerator g) throws java.io.IOException {
            g.writeStartObject(); g.writeObjectField("FLD-AMOUNT", v_ce4f5e6c05433529cf6a3cbb); g.writeEndObject();
        }
    }


    @JsonDeserialize(using=T_305cfa7a67e100113cf3b5c1.Reader.class)
    @JsonSerialize(using=T_305cfa7a67e100113cf3b5c1.Writer.class)
    public record T_305cfa7a67e100113cf3b5c1(@JsonProperty("INPUT-TASK-RESOURCE") T_2f6d38b95ca9030968971abdId v_e7b57753ec9f285a96fb2f3e, @JsonProperty("INPUT-TASK-TEXT") String v_347ddac30084d7e07a116384) {
        public T_305cfa7a67e100113cf3b5c1 {   java.util.Objects.requireNonNull(v_e7b57753ec9f285a96fb2f3e, "INPUT-TASK-RESOURCE"); java.util.Objects.requireNonNull(v_347ddac30084d7e07a116384, "INPUT-TASK-TEXT"); if (v_347ddac30084d7e07a116384 != null) validText(v_347ddac30084d7e07a116384); }
        public static T_305cfa7a67e100113cf3b5c1 read(JsonNode n) {
            shape(n, java.util.Set.of("INPUT-TASK-RESOURCE", "INPUT-TASK-TEXT"));
            return new T_305cfa7a67e100113cf3b5c1(new T_2f6d38b95ca9030968971abdId(text(required(n, "INPUT-TASK-RESOURCE"))), text(required(n, "INPUT-TASK-TEXT")));
        }
        public static final class Reader extends JsonDeserializer<T_305cfa7a67e100113cf3b5c1> {
            @Override public T_305cfa7a67e100113cf3b5c1 deserialize(JsonParser p, DeserializationContext c) throws java.io.IOException {
                try { return read(p.getCodec().readTree(p)); }
                catch (RuntimeException e) { throw JsonMappingException.from(p, "SEMANTIC_INPUT", e); }
            }
        }
        public static final class Writer extends JsonSerializer<T_305cfa7a67e100113cf3b5c1> {
            @Override public void serialize(T_305cfa7a67e100113cf3b5c1 value, JsonGenerator g, SerializerProvider p) throws java.io.IOException {
                value.write(g);
            }
        }
        private void write(JsonGenerator g) throws java.io.IOException {
            g.writeStartObject(); g.writeObjectField("INPUT-TASK-RESOURCE", v_e7b57753ec9f285a96fb2f3e); g.writeObjectField("INPUT-TASK-TEXT", v_347ddac30084d7e07a116384); g.writeEndObject();
        }
    }


    @JsonDeserialize(using=T_63ac0912c55a775e2bee74f0.Reader.class)
    @JsonSerialize(using=T_63ac0912c55a775e2bee74f0.Writer.class)
    public record T_63ac0912c55a775e2bee74f0(@JsonProperty("OPERATION-TEXT") String v_deec9bdbe82e43bdd713decc) {
        public T_63ac0912c55a775e2bee74f0 {  java.util.Objects.requireNonNull(v_deec9bdbe82e43bdd713decc, "OPERATION-TEXT"); if (v_deec9bdbe82e43bdd713decc != null) validText(v_deec9bdbe82e43bdd713decc); }
        public static T_63ac0912c55a775e2bee74f0 read(JsonNode n) {
            shape(n, java.util.Set.of("OPERATION-TEXT"));
            return new T_63ac0912c55a775e2bee74f0(text(required(n, "OPERATION-TEXT")));
        }
        public static final class Reader extends JsonDeserializer<T_63ac0912c55a775e2bee74f0> {
            @Override public T_63ac0912c55a775e2bee74f0 deserialize(JsonParser p, DeserializationContext c) throws java.io.IOException {
                try { return read(p.getCodec().readTree(p)); }
                catch (RuntimeException e) { throw JsonMappingException.from(p, "SEMANTIC_INPUT", e); }
            }
        }
        public static final class Writer extends JsonSerializer<T_63ac0912c55a775e2bee74f0> {
            @Override public void serialize(T_63ac0912c55a775e2bee74f0 value, JsonGenerator g, SerializerProvider p) throws java.io.IOException {
                value.write(g);
            }
        }
        private void write(JsonGenerator g) throws java.io.IOException {
            g.writeStartObject(); g.writeObjectField("OPERATION-TEXT", v_deec9bdbe82e43bdd713decc); g.writeEndObject();
        }
    }


    @JsonDeserialize(using=T_781a0c95aa44b66be234c99e.Reader.class)
    @JsonSerialize(using=T_781a0c95aa44b66be234c99e.Writer.class)
    public record T_781a0c95aa44b66be234c99e(@JsonProperty("RESULT-TEXT") String v_76ef0afed24f454088596039) {
        public T_781a0c95aa44b66be234c99e {  java.util.Objects.requireNonNull(v_76ef0afed24f454088596039, "RESULT-TEXT"); if (v_76ef0afed24f454088596039 != null) validText(v_76ef0afed24f454088596039); }
        public static T_781a0c95aa44b66be234c99e read(JsonNode n) {
            shape(n, java.util.Set.of("RESULT-TEXT"));
            return new T_781a0c95aa44b66be234c99e(text(required(n, "RESULT-TEXT")));
        }
        public static final class Reader extends JsonDeserializer<T_781a0c95aa44b66be234c99e> {
            @Override public T_781a0c95aa44b66be234c99e deserialize(JsonParser p, DeserializationContext c) throws java.io.IOException {
                try { return read(p.getCodec().readTree(p)); }
                catch (RuntimeException e) { throw JsonMappingException.from(p, "SEMANTIC_INPUT", e); }
            }
        }
        public static final class Writer extends JsonSerializer<T_781a0c95aa44b66be234c99e> {
            @Override public void serialize(T_781a0c95aa44b66be234c99e value, JsonGenerator g, SerializerProvider p) throws java.io.IOException {
                value.write(g);
            }
        }
        private void write(JsonGenerator g) throws java.io.IOException {
            g.writeStartObject(); g.writeObjectField("RESULT-TEXT", v_76ef0afed24f454088596039); g.writeEndObject();
        }
    }


    @JsonDeserialize(using=T_e83d48b36740f933d67f64d0.Reader.class)
    @JsonSerialize(using=T_e83d48b36740f933d67f64d0.Writer.class)
    public record T_e83d48b36740f933d67f64d0(@JsonProperty("OUTPUT-TASK-TEXT") String v_dd38e57e1fff01860a1d756d) {
        public T_e83d48b36740f933d67f64d0 {  java.util.Objects.requireNonNull(v_dd38e57e1fff01860a1d756d, "OUTPUT-TASK-TEXT"); if (v_dd38e57e1fff01860a1d756d != null) validText(v_dd38e57e1fff01860a1d756d); }
        public static T_e83d48b36740f933d67f64d0 read(JsonNode n) {
            shape(n, java.util.Set.of("OUTPUT-TASK-TEXT"));
            return new T_e83d48b36740f933d67f64d0(text(required(n, "OUTPUT-TASK-TEXT")));
        }
        public static final class Reader extends JsonDeserializer<T_e83d48b36740f933d67f64d0> {
            @Override public T_e83d48b36740f933d67f64d0 deserialize(JsonParser p, DeserializationContext c) throws java.io.IOException {
                try { return read(p.getCodec().readTree(p)); }
                catch (RuntimeException e) { throw JsonMappingException.from(p, "SEMANTIC_INPUT", e); }
            }
        }
        public static final class Writer extends JsonSerializer<T_e83d48b36740f933d67f64d0> {
            @Override public void serialize(T_e83d48b36740f933d67f64d0 value, JsonGenerator g, SerializerProvider p) throws java.io.IOException {
                value.write(g);
            }
        }
        private void write(JsonGenerator g) throws java.io.IOException {
            g.writeStartObject(); g.writeObjectField("OUTPUT-TASK-TEXT", v_dd38e57e1fff01860a1d756d); g.writeEndObject();
        }
    }


    @JsonDeserialize(using=T_73ec76bc5a3273ce8251ca7c.Reader.class)
    @JsonSerialize(using=T_73ec76bc5a3273ce8251ca7c.Writer.class)
    public record T_73ec76bc5a3273ce8251ca7c(@JsonProperty("QUERY-TEXT") String v_d456657b12367788740f9907) {
        public T_73ec76bc5a3273ce8251ca7c {  java.util.Objects.requireNonNull(v_d456657b12367788740f9907, "QUERY-TEXT"); if (v_d456657b12367788740f9907 != null) validText(v_d456657b12367788740f9907); }
        public static T_73ec76bc5a3273ce8251ca7c read(JsonNode n) {
            shape(n, java.util.Set.of("QUERY-TEXT"));
            return new T_73ec76bc5a3273ce8251ca7c(text(required(n, "QUERY-TEXT")));
        }
        public static final class Reader extends JsonDeserializer<T_73ec76bc5a3273ce8251ca7c> {
            @Override public T_73ec76bc5a3273ce8251ca7c deserialize(JsonParser p, DeserializationContext c) throws java.io.IOException {
                try { return read(p.getCodec().readTree(p)); }
                catch (RuntimeException e) { throw JsonMappingException.from(p, "SEMANTIC_INPUT", e); }
            }
        }
        public static final class Writer extends JsonSerializer<T_73ec76bc5a3273ce8251ca7c> {
            @Override public void serialize(T_73ec76bc5a3273ce8251ca7c value, JsonGenerator g, SerializerProvider p) throws java.io.IOException {
                value.write(g);
            }
        }
        private void write(JsonGenerator g) throws java.io.IOException {
            g.writeStartObject(); g.writeObjectField("QUERY-TEXT", v_d456657b12367788740f9907); g.writeEndObject();
        }
    }

public record Da912bf8c8345dd6fbf51c477(java.math.BigDecimal value) {
                public Da912bf8c8345dd6fbf51c477 { java.util.Objects.requireNonNull(value); value = value.setScale(2, java.math.RoundingMode.UNNECESSARY); if (value.precision() > 18) throw new IllegalArgumentException("DECIMAL_PRECISION"); }
                @JsonValue public String wire() { return value.toPlainString(); } public String currency() { return "UGX"; }
            }
}
