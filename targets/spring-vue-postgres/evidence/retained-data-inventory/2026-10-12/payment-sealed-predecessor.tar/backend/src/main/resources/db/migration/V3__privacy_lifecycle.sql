CREATE TABLE acp_lifecycle_anchor (
 lifecycle text NOT NULL,revision integer NOT NULL,tenant bytea NOT NULL,resource bytea NOT NULL,
 entity text NOT NULL,machine text NOT NULL,machine_revision integer NOT NULL,closing_state text NOT NULL,state_revision integer NOT NULL,
 anchor_xid text,anchor_ns numeric,root_version bigint NOT NULL,last_ns numeric,
 status text NOT NULL,attempt_xid text,completed_ns numeric,
 PRIMARY KEY(lifecycle,revision,tenant,resource));
CREATE TABLE acp_lifecycle_attempt (
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,lifecycle text NOT NULL,revision integer NOT NULL,tenant bytea NOT NULL,resource bytea NOT NULL,
 observed_ns numeric NOT NULL,result text NOT NULL,action_xid text);
CREATE TABLE acp_lifecycle_release_audit (
 lifecycle text NOT NULL,revision integer NOT NULL,tenant bytea NOT NULL,resource bytea NOT NULL,
 hold text NOT NULL,hold_revision integer NOT NULL,permission text NOT NULL,permission_revision integer NOT NULL,subject bytea NOT NULL,
 action_xid text NOT NULL);
INSERT INTO acp_lifecycle_anchor(lifecycle,revision,tenant,resource,entity,machine,machine_revision,closing_state,state_revision,root_version,status) SELECT 'LIFECYCLE-ENT-PAYMENT',3,f_55326825932184ca370c199a,f_8306508e7c606f32081c13bb,'ENT-PAYMENT','WF-PAYMENT',2,'STATE-POSTED',2,acp_version,'LEGACY_UNPROVEN' FROM e_2f6d38b95ca9030968971abd WHERE acp_state='STATE-POSTED';
